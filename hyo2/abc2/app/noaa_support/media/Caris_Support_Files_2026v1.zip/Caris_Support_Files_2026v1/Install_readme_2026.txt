Version 2026

Unzip the Caris support files into the C:\CARIS directory. This should create a new folder named
C:\CARIS\CARIS_Support_Files_2026v1 that contains the support files and folders.

The batch file is named CARIS_Support_Files_2026v1.bat. Retain the default file paths and registry entries in the batch
file or reconfigure as desired. Execute the batch file logged in as administrator with all other users logged off the system.

The batch file (CARIS_Support_Files_2026v1.bat) will copy Version 2026 of the NOAA CARIS support files from the
C:\CARIS\CARIS_Support_Files_2026v1 folder to the correct CARIS folders on your machine. The process will only work if
you have the support files stored in a C:\CARIS\CARIS_Support_Files_2026v1 folder.

The support files should be copied as below:

BASE Editor 5.5:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-5.5-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-5.5-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-5.5-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-5.5-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-5.5-modules-Basic Charting Tools-support-Rules

Easyview 6.1:
<System_Files> ----------------------------->C-Program Files-CARIS-EasyView-6.1-System
<Profiles_Pools_ProductInfo>---------------->C-Program Files-CARIS-EasyView-6.1-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-EasyView-6.1-System-S57Config-Symbolization-Lookup

HIPS & SIPS 11.4
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-11.4-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-11.4-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-11.4-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-11.4-System-S57Config-Symbolization-Lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-HIPS and SIPS-11.4-modules-support-Compilation4-Rules

HIPS & SIPS 12.1
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-12.1-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-12.1-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-12.1-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-12.1-System-S57Config-Symbolization-Lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-HIPS and SIPS-12.1-modules-support-Compilation4-Rules

S57 Composer
<System_Files> ----------------------------->C-CARIS-S-57 Composer-30-System
<Profiles_Pools>---------------------------->C-CARIS-S-57 Composer-30-System-S57Config-System
<ProductInfo>------------------------------->C-CARIS-S-57 Composer-30-System-ProductInfoFiles
<Symbolization>----------------------------->C-CARIS-S-57 Composer-30-System-S57Config-Symbolization-Lookup

      - File Versions -

atr_lut.txt						= Version 2026
obj_lut.txt						= Version 2026
NOAA_cataloguecontrol.xml		= Version 2026
NOAA Profile Version 2026.xml	= Version 2026
NOAAunifiedPool.xml				= Version 2026
s57productinfo_NOAA.xml			= Version 2026
psymrefs.dic					= Version 2026
psymreft.dic					= Version 2026
HIPS2NOAAHOB.xml        		= Version 2026

